import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:superbot_app2/bluetooth_state.dart';
import 'package:flutter_blue/flutter_blue.dart' as blue;

class ScanPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: Provider.of<Bluetooth>(context).scanForDevices(),
        builder: (context, snapshot) {
          if (snapshot.hasData)
            return Scaffold(body: AvailableDevices(snapshot.data));
          return Scaffold(
            appBar: AppBar(
              title: Text('Select Device'),
            ),
            body: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: CircularProgressIndicator(),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text('Scanning for bluetooth devices'),
                  ],
                ),
              ],
            ),
          );
        });
  }
}

class AvailableDevices extends StatelessWidget {
  AvailableDevices(this.availableBLEDevices);
  final Map<blue.DeviceIdentifier, blue.ScanResult> availableBLEDevices;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          label: Text('SCAN'),
          icon: Icon(Icons.search),
          onPressed: () {
            print('scanning');
            Provider.of<Bluetooth>(context).setMode(BleAppState.searching);
          },
        ),
        appBar: AppBar(
//        leading: Icon(Icons.menu),
          title: Text("Select Device"),
          actions: <Widget>[
            IconButton(
              onPressed: () {
                print('Exiting');
//              _ackAlert(context);
//              SystemChannels.platform.invokeMethod('SystemNavigator.pop');
              },
              icon: Icon(Icons.menu),
              color: Colors.white,
            ),
          ],
        ),
        body: ListView(
            children: availableBLEDevices.values
                .where((result) => result.device.name.length > 0)
                .map<Widget>((result) => ListTile(
                      trailing: (result.device.name == 'Nordic_TUDAO')
                          ? Chip(
                              label: Text('Superbot Detected',
                              style: TextStyle(color: Colors.white)),
                              backgroundColor: Colors.redAccent,
                            )
                          : null,
//                      Chip(
//                          label: Text('SuperBot Detected'),
//                      ),
                      leading: Icon(Icons.bluetooth),
                      title: Text(result.device.name,
                          style: TextStyle(
                              fontSize: 18.0, fontWeight: FontWeight.bold)),
                      subtitle: Text(result.device.id.toString()),
                      onTap: () => Provider.of<Bluetooth>(context)
                          .connectToDevice(result.device),
                    ))
                .toList()));
  }
}

//class ScanPage extends StatelessWidget {
//  Future<void> _ackAlert(BuildContext context) {
//    return showDialog<void>(
//      context: context,
//      builder: (BuildContext context) {
//        return AlertDialog(
//          title: Text('Exit'),
//          content: const Text('Are you sure you want to exit the application?'),
//          actions: <Widget>[
//            FlatButton(
//              child: Text('OK', style: TextStyle(fontSize: 18.0)),
//              onPressed: () {
//                SystemChannels.platform.invokeMethod('SystemNavigator.pop');
//              },
//            ),
//          ],
//        );
//      },
//    );
//  }
//
//  @override
//  Widget build(BuildContext context) {
//    return Scaffold(
//      floatingActionButton: FloatingActionButton.extended(
//        label: Text('Scan'),
//        icon: Icon(Icons.search),
//        onPressed: () {
//          print('scanning');
//        },
//      ),
//      appBar: AppBar(
////        leading: Icon(Icons.menu),
//        title: Text("Select device"),
//        actions: <Widget>[
//          IconButton(
//            onPressed: () {
//              print('Exiting');
//              _ackAlert(context);
////              SystemChannels.platform.invokeMethod('SystemNavigator.pop');
//            },
//            icon: Icon(Icons.menu),
//            color: Colors.white,
//          ),
//        ],
//      ),
//      body: ListView(
//        children: <Widget>[
//          Divider(color: Colors.black),
//          ListTile(
//            leading: Icon(Icons.bluetooth),
//            trailing: Chip(
//              label: Text('SuperBot Detected',
//                  style: TextStyle(color: Colors.white)),
//              backgroundColor: Colors.redAccent,
//            ),
//            contentPadding: EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 0.0),
//            title: Text('Nordic_TUDAO',
//                style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold)),
//            subtitle: Text('RSSI -56'),
//            onTap: () {
//              Navigator.pushNamed(context, '/control');
//            },
//          ),
//          Divider(color: Colors.black),
//        ],
//      ),
//    );
//  }
//}